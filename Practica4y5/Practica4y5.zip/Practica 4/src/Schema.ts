import {gql } from 'apollo-server'

export const typeDefs = gql`
type Ingredient{
    id: String!
    name: String!
    recipes: [Recipe!]!
}

type Recipe{
    id: ID!
    title: String!
    description: String!
    ingredients: [Ingredient!]!
    author: User
}

  
type User{
    id: ID!
    email: String
    password: String!
    token: String
    recipes: [Recipe!]!
}

type Query {
    getIngredient(id:String!): Ingredient!
    getIngredients: [Ingredient]!
    getRecipes(author: ID, ingredient: String): [Recipe!]!
    getRecipe(id:ID!): Recipe

    getUser(id: ID!): User!
    getUsers: [User!]!
    
}


type Mutation {
      signIn(email: String!, password: String!): User! 
      signOut(token: String!):String!
      logIn(email: String!, password: String!):User!
      logOut(token: String!): String!
     
      deleteIngredient(id:String!): String!
      addIngredient(name: String!):Ingredient!
      addRecipe(title: String!, description: String!, ingredients: [String!]!): Recipe!
      updateRecipe(id: ID!,title: String, description: String ):Recipe!
      deleteRecipe(id: ID!): String!

}

  `

