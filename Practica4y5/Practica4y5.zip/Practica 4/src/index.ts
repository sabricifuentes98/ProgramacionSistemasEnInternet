console.log ("Hola Mundo");
import { Db, Collection } from "mongodb";
import {mongoConexion} from "./mongoConnection"
import { authenticate } from "./auth";
import { typeDefs } from "./Schema"; //Tipos
import { Query } from "./resolvers/query";
import { Mutation } from "./resolvers/mutations";
import dotenv from "dotenv";

const { ApolloServer, gql } = require('apollo-server');

const resolvers = {
    Query,
    Mutation
}

const run = async () => {
    dotenv.config();
    console.log("Connecting to DB...");
    const db: Db = await mongoConexion();
    console.log("Connected to database");
    
    const users = db.collection("Usuarios");
    const recipes = await db.collection("Recetas");
    const ingredients = await db.collection("Ingredientes");
    debugger;

    const server = new ApolloServer({
        typeDefs,
        resolvers,
        context: async ({req,res}:{req:any, res:any}) => {
            const forbidden = ["SignIn","SignOut","addIngredient","signOut"];
            return {
                users, 
                recipes,
                ingredients,
            }
        }
    });

    server.listen(3000).then(() => {
        console.log("Server escuchando del puerto 3000")
    })
}

try {
    run();
} catch (e) {
    console.log(e);
}




//npm run start-inspect