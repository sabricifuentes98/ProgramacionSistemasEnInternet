import { Db, MongoClient } from "mongodb";
import dotenv from "dotenv";

export const mongoConexion = async (): Promise<Db> => {
  const dbName: string = "Blog";
  

const mongouri:string="mongodb+srv://penelope:1998gpao@cluster0.38hvb.mongodb.net/${dbName}?retryWrites=true&w=majority";
  const client = new MongoClient(mongouri);

  try {
    await client.connect();
    console.log("MongoDB connected");
      return client.db(dbName);
  } catch (e) {
    throw e;
  }
};


/*
dotenv.config();

export const mongoConexion = async (): Promise<Db> => {
   
    const name = process.env.DB_NAME;
    const username = process.env.DB_USERNAME;
    const pws = process.env.DB_PASSWORD;
    const cluster = process.env.DB_CLUSTER;
  const mongouri:string="mongodb+srv://${username}:${pws}@${cluster}/Blog?retryWrites=true&w=majority";
    const client = new MongoClient(mongouri);
  
    try {
      await client.connect();
      console.log("MongoDB connected");
        return client.db(name);
    } catch (e) {
      throw e;
    }
  };

*/
