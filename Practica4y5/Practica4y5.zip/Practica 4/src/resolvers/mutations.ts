
import { ApolloServer, ApolloError } from "apollo-server"
import { mongoConexion } from "../mongoConnection";
import { Collection, Db } from "mongodb";
import { v4 as uuidv4 } from "uuid";
const ObjectId = require('mongodb').ObjectId;
import { Ingredient,User,Recipe } from "../types";
import { encriptar, desencriptar } from "../otherFunctions";
import { env } from "process";
export const Mutation = {
    signIn: async (parent: any, args: { email: string, password: string }, context: { users: Collection }) => {
        const user = await context.users.findOne({ email: args.email });
        if (!user) {
            
            const usuario: User = {
                email: (args.email),
                password: encriptar((args.password)),
                token: uuidv4()
            };
            await context.users.insertOne(usuario);
            const addedUser = await context.users.findOne({ email: args.email });
            if (addedUser) {

                return {
                    id: addedUser._id,
                    email: addedUser.email as string,
                    password: addedUser.password as string,
                    token: addedUser.token as string,
                    //Falta agregar las recetas
                }
            }
        } else {
            throw new ApolloError('Usuario ya registrado', 'MY_ERROR_CODE');
        }
    },
    addIngredient: async (parent:any, args:{name: string},context:{ingredients: Collection})=>{
        const ingredient = await context.ingredients.findOne({name: args.name});
        if(ingredient){
            throw new ApolloError('El ingrediente ya existe.');
        }else{
            const ingrediente: Ingredient = {
                name: (args.name),
                _id: new ObjectId,
            };
            await context.ingredients.insertOne(ingrediente);
            const addedRecipe = await context.ingredients.findOne({name: args.name});
            if(addedRecipe){
                return{
                    id: addedRecipe._id,
                    name: addedRecipe.name as String,
                    //Falta agregar las recetas
                }
            }
        }
    },
    signOut: async (parent:any, args:{token: string},context: {users: Collection})=> {
        //Permite a un usuario loggeado borrar su cuenta. Borra todas sus recetas.
        const deletedUSer= await context.users.deleteOne({"token": args.token});
        const user = await context.users.findOne({token: args.token});
        if(user){
            return "El usuario no ha podido ser borrado";

        }else{
            console.log("Usuario borrado");
            return "El usuario ha sido borrado con exito";

        }
        
    },
    logIn: async (parent:any,args: {email: string, password: string},context: {users: Collection})=>{
        //Permite loggearse con usuario y contraseña.
        const user = await context.users.findOne({email: args.email, password: args.password})
        if(user){
            return{
                email: user.email as String,
                token: user.token as String,
                //falta las recetas del usuario
            }
        }else{
            console.log("El usuario no existe en mongo");
        }

    },
    logOut: async (parent:any,args: {token: string},context: {users: Collection}) =>{
        //Funciona con updateOne pero no con findOneAndUpdate -.-
        const user = await context.users.updateOne({token: args.token}, {
            $set:{
                token: null,
            }
        });
       const updatedTokenUser = await context.users.findOne({token: args.token});
       if(!updatedTokenUser){
           return "El token del usuario ha sido borrado.";
           
       }else{
           throw new ApolloError("No se encontró el token");
       }
        
    },
    deleteIngredient: async (parent:any, args: {id:string}, context: {ingredients: Collection}) => {
        const ingredient = await context.ingredients.findOne({"_id": new ObjectId(args.id)});
        if(ingredient){
            const deletedIngredient = await context.ingredients.deleteOne({"_id": new ObjectId(args.id)},);
            return "Ingrediente borrado"
        }else{
            throw new ApolloError("Ingrediente no borrado");
            
        }
        
    },
    addRecipe: async (parent:any, args: {title:string, desciption: string, ingredients: [string]}, context: {recipes: Collection, user: User, users: Collection}) => {
        const recetaEncontrada = await context.recipes.findOne({title: args.title});
        if(recetaEncontrada){
            throw new ApolloError("La receta ya existe ", "403");
        }else{

            const newRecipe = {
                ...args,
                author: process.env.AUTHOR,
            }
            context.recipes.insertOne(newRecipe);
            return newRecipe;
            console.log("Receta anadida");

        }
    },
    deleteRecipe: async (parent:any, args: {id:string}, context: {recipes: Collection}) => {
        const recipe = await context.recipes.findOne({_id: new ObjectId(args.id)});
        if(recipe){
            const deletedIngredient = await context.recipes.deleteOne({_id: new ObjectId(args.id)});
            return "La receta se ha borrado con exito";
        }else{
            console.log("Receta NO borrada");
            return "El Receta no se ha podido borrar";
        }
        
    },
    
    updateRecipe: async (parent:any, args: {id:string, title:string,description:string}, context: {recipes: Collection}) => {
        const recipe = await context.recipes.findOne({_id: new ObjectId(args.id)});
        if(recipe){
            const updatedRecipe = await context.recipes.updateOne({_id: new ObjectId(args.id)},{
                $set:{
                    title: args.title,
                    description: args.description,
                }
            })
            return updatedRecipe;

        }else{
            throw new ApolloError("El id de la receta no se encontró");
        }
        
    },



    

}