
import { ApolloServer, ApolloError } from "apollo-server"
import { typeDefs } from "../Schema"
import { Collection, Db, ObjectId } from "mongodb";
import { v4 as uuidv4 } from "uuid";



export const Query = {
    
    getUser: async (parent: any, args: {id: string}, context: { users: Collection})=>{
        //Nos devuelve el usuario
        const id = args.id;
        const validId = new ObjectId(id);
        let user = await context.users.findOne( {_id:validId} );
        if(user){
            return {
                id: user._id,
                email: user.email,
                token: user.token
            }
        }else{
            console.log("Usuario no encontrado");
        }

    },
    getUsers: async ( parent: any, args: any ,context: {users: Collection}) =>{
        const users = await context.users.find().toArray();
        return  users.map(elem =>({
            ...elem,
            id: elem._id.toString()
            // id: elem._id;
            // email: elem.email;
            // token: elem.token;
            // password: elem.password;

        }))
        
    },
    getRecipe: async (parent: any, args: {id:string}, context:{recipes: Collection}) =>{
        const recipe = await context.recipes.findOne({_id: new ObjectId(args.id)});
        if(recipe){
            return {
                ...recipe,
                id: recipe._id.toString()
            }
        }
    },
    getRecipes: async (parent:any, args: {author: string, ingredient: string},context: {recipes: Collection})=>{
        const recetasAuthor = await context.recipes.find().toArray();
        const recetasIngredient = await context.recipes.find().toArray();
        if(recetasAuthor){
            return recetasAuthor.map(elem => ({
                ...elem,
                id: elem._id.toString()
            }))
        }
        if(recetasIngredient){
            return recetasIngredient.map(elem => ({
                ...elem,
                id: elem._id.toString()
            }))
        }
        
        
        
    },
    getIngredient: async(parent: any, args: any, context: {ingredients: Collection})  =>{ 
        const id = args.id;
        const validId = new ObjectId(id);
        let ingredient = await context.ingredients.findOne({_id: validId})

        if(ingredient) {
            return {
                ...ingredient
            }
        }


    },
    getIngredients: async(parent: any, args: any, context: {ingredients: Collection}) => {
        const ingredients = await context.ingredients.find().toArray();

        return ingredients.map(elem => ({
            ...elem,
            id: elem._id.toString()
        }))

    },
    /*getRecipes: async (parent:any, args: {ingredient: string},context: {recipes: Collection})=>{
        const recetas = await context.recipes.find().toArray();
        return recetas.map(elem => ({
            ...elem,
            id: elem._id.toString()
        }))
        
        
    }*/
}