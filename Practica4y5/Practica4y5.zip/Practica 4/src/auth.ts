export const authenticate = (req:any,res:any)=>{
    const forbidden = ["test","pepi"];
    if(forbidden.some( q=> req.body.query.includes(q))){
        return res.sendStatus(403).send("Forbidden");
    }

}