import { ObjectId } from "mongodb"


export type Ingredient = {
    _id: ObjectId,
    name: string,
    recipes?: [Recipe]
}
export type Recipe = {
    id?: ObjectId,
    title?: string,
    description?: string,
    ingredients?: [Ingredient],
    author?: User
}
export type User = {
    _id?: ObjectId,
    email?: string,
    password?: string,
    token: string,
    recipes?: [Recipe]
}