
const brcypt = require("bcrypt");

export const encriptar = (password: string) => {
    return brcypt.hashSync(password, 15);
}

export const desencriptar = (password: string, hash: string) => {
    return brcypt.compareSync(password, hash);//compara la contraseña con el hash
}
